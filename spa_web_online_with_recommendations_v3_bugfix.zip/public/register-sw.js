export function registerServiceWorker() {
	if (!('serviceWorker' in navigator)) return;
	window.addEventListener('load', async () => {
		try {
			await navigator.serviceWorker.register('/sw.js');
			console.log('Service worker registered');
		} catch (e) {
			console.warn('SW register failed', e);
		}
	});
}
