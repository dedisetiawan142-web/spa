import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js';
import {
	getAuth,
	onAuthStateChanged,
	signInWithEmailAndPassword,
	createUserWithEmailAndPassword,
	signOut,
} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js';
import {
	getFirestore,
	doc,
	getDoc,
	setDoc,
	collection,
	addDoc,
	onSnapshot,
	query,
	where,
	orderBy,
	deleteDoc,
	updateDoc,
	serverTimestamp,
	Timestamp,
	getDocs,
	limit,
} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js';

/* ===== Config ===== */
const cfg = window.__FIREBASE_CONFIG__;
if (!cfg || !cfg.apiKey || !cfg.projectId) {
	console.warn('Firebase config belum diisi. Edit public/firebase-config.js');
}

const app = initializeApp(cfg);
const auth = getAuth(app);
const db = getFirestore(app);

/* ===== DOM ===== */
const el = (id) => document.getElementById(id);
const year = el('year');
year.textContent = String(new Date().getFullYear());

const authState = el('authState');
const roleState = el('roleState');
const btnLogout = el('btnLogout');

const email = el('email');
const password = el('password');
const btnLogin = el('btnLogin');
const btnRegister = el('btnRegister');
const loginMsg = el('loginMsg');

// customer booking form
const bookingForm = el('bookingForm');
const cName = el('cName');
const cPhone = el('cPhone');
const serviceSel = el('service');
const therapistSel = el('therapist');
const durationSel = el('duration');
const dateInp = el('date');
const timeInp = el('time');
const notesInp = el('notes');
const bookingHint = el('bookingHint');

const myBookings = el('myBookings');
const myCount = el('myCount');

// recommendations
const recommendations = el('recommendations');
const recHint = el('recHint');

// admin
const statGrid = el('statGrid');
const allBookings = el('allBookings');
const allCount = el('allCount');
const btnSeed = el('btnSeed');

// master data
const svcName = el('svcName');
const svcPrice = el('svcPrice');
const btnAddService = el('btnAddService');
const svcTable = el('svcTable');

const thName = el('thName');
const btnAddTherapist = el('btnAddTherapist');
const thTable = el('thTable');

const pName = el('pName');
const pSku = el('pSku');
const pQty = el('pQty');
const btnAddProduct = el('btnAddProduct');
const pTable = el('pTable');

/* ===== Helpers ===== */
const pad2 = (n) => String(n).padStart(2, '0');
const toISODate = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const nowHHMM = () => {
	const d = new Date();
	return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
};
const hhmmToMin = (hhmm) => {
	const [h, m] = (hhmm || '00:00').split(':').map((x) => parseInt(x, 10));
	return (h || 0) * 60 + (m || 0);
};
const minToHHMM = (mins) => `${pad2(Math.floor(mins / 60))}:${pad2(mins % 60)}`;
const escapeHtml = (s) => String(s ?? '')
	.replaceAll('&', '&amp;')
	.replaceAll('<', '&lt;')
	.replaceAll('>', '&gt;')
	.replaceAll('"', '&quot;');

function badgeVariant(status) {
	switch (status) {
		case 'Pending': return 'orange';
		case 'Confirmed': return 'blue';
		case 'Completed': return 'green';
		case 'Canceled': return 'red';
		default: return 'blue';
	}
}

/* ===== Auth + Role ===== */
let CURRENT_USER = null;
let CURRENT_ROLE = null; // admin|staff|customer

async function ensureUserDoc(uid, emailStr, role = 'customer') {
	const ref = doc(db, 'users', uid);
	const snap = await getDoc(ref);
	if (!snap.exists()) {
		await setDoc(ref, { email: emailStr, role, createdAt: serverTimestamp() });
	}
}

async function fetchRole(uid) {
	const ref = doc(db, 'users', uid);
	const snap = await getDoc(ref);
	return snap.exists() ? (snap.data().role || 'customer') : 'customer';
}

function setAuthUi({ user, role }) {
	if (!user) {
		authState.textContent = 'Belum login';
		authState.dataset.variant = 'orange';
		roleState.style.display = 'none';
		btnLogout.style.display = 'none';
		return;
	}
	authState.textContent = user.email || 'Login';
	authState.dataset.variant = 'green';
	roleState.style.display = 'inline-flex';
	roleState.textContent = role;
	roleState.dataset.variant = role === 'customer' ? 'blue' : 'green';
	btnLogout.style.display = 'inline-flex';
}

btnLogin.addEventListener('click', async () => {
	loginMsg.textContent = '';
	try {
		const cred = await signInWithEmailAndPassword(auth, email.value.trim(), password.value);
		await ensureUserDoc(cred.user.uid, cred.user.email, 'customer');
		loginMsg.textContent = 'Login sukses.';
	} catch (e) {
		loginMsg.textContent = 'Gagal login: ' + (e?.message || e);
	}
});

btnRegister.addEventListener('click', async () => {
	loginMsg.textContent = '';
	try {
		const cred = await createUserWithEmailAndPassword(auth, email.value.trim(), password.value);
		await ensureUserDoc(cred.user.uid, cred.user.email, 'customer');
		loginMsg.textContent = 'Daftar sukses. (role customer)';
	} catch (e) {
		loginMsg.textContent = 'Gagal daftar: ' + (e?.message || e);
	}
});

btnLogout.addEventListener('click', async () => {
	await signOut(auth);
});

/* ===== Master data watchers ===== */
let SERVICES = []; // {id,name,price}
let THERAPISTS = []; // {id,name}

// unsubscribe handles (bug fix: prevent duplicate listeners after re-login / role change)
let unsubServices = null;
let unsubTherapists = null;
let unsubProducts = null;
let unsubMyBookings = null;
let unsubAllBookings = null;

function stopAllWatchers() {
	[unsubServices, unsubTherapists, unsubProducts, unsubMyBookings, unsubAllBookings].forEach((u) => {
		try {
			if (typeof u === 'function') u();
		} catch {}
	});
	unsubServices = unsubTherapists = unsubProducts = unsubMyBookings = unsubAllBookings = null;
}

function renderServiceSelect() {
	serviceSel.innerHTML = '';
	for (const s of SERVICES) {
		const opt = document.createElement('option');
		opt.value = s.id;
		opt.textContent = `${s.name} — Rp${s.price}`;
		opt.dataset.price = String(s.price);
		opt.dataset.name = s.name;
		serviceSel.appendChild(opt);
	}
}
function renderTherapistSelect() {
	therapistSel.innerHTML = '';
	for (const t of THERAPISTS) {
		const opt = document.createElement('option');
		opt.value = t.id;
		opt.textContent = t.name;
		opt.dataset.name = t.name;
		therapistSel.appendChild(opt);
	}
}

function startMasterWatchers(role) {
	// clear previous to avoid multiple subscriptions
	try { unsubServices?.(); } catch {}
	try { unsubTherapists?.(); } catch {}
	try { unsubProducts?.(); } catch {}
	unsubServices = unsubTherapists = unsubProducts = null;

	unsubServices = onSnapshot(query(collection(db, 'services'), orderBy('name')), (snap) => {
		SERVICES = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
		renderServiceSelect();
		renderServicesTable();
	});
	unsubTherapists = onSnapshot(query(collection(db, 'therapists'), orderBy('name')), (snap) => {
		THERAPISTS = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
		renderTherapistSelect();
		renderTherapistsTable();
	});
	// products hanya untuk admin/staff. Untuk customer jangan subscribe (hindari permission error).
	if (role === 'admin' || role === 'staff') {
		unsubProducts = onSnapshot(
			query(collection(db, 'products'), orderBy('name')),
			(snap) => {
				renderProductsTable(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
			},
			(err) => {
				console.warn('Products watcher error', err);
				renderProductsTable([]);
			}
		);
	} else {
		renderProductsTable([]);
	}
}

/* ===== Customer booking ===== */
function refreshHint() {
	if (!SERVICES.length || !THERAPISTS.length) {
		bookingHint.textContent = ' • master data belum ada (seed dulu sebagai admin/staff).';
		return;
	}
	const dur = parseInt(durationSel.value, 10) || 60;
	const startM = hhmmToMin(timeInp.value);
	const endM = startM + dur;
	bookingHint.textContent = ` • estimasi selesai: ${minToHHMM(endM)}`;
}

[durationSel, dateInp, timeInp].forEach((x) => x.addEventListener('change', refreshHint));

bookingForm.addEventListener('submit', async (e) => {
	e.preventDefault();
	if (!CURRENT_USER) return alert('Harus login.');
	if (!serviceSel.value || !therapistSel.value) return alert('Pilih layanan & terapis.');

	const startAtDate = new Date(`${dateInp.value}T${timeInp.value}:00`);
	const durationMin = parseInt(durationSel.value, 10) || 60;
	const endAtDate = new Date(startAtDate.getTime() + durationMin * 60000);

	// basic overlap check (client-side)
	const overlapQ = query(
		collection(db, 'bookings'),
		where('therapistId', '==', therapistSel.value),
		where('status', 'in', ['Pending', 'Confirmed', 'Completed']),
		where('startAt', '<', Timestamp.fromDate(endAtDate)),
		orderBy('startAt', 'desc'),
		limit(20)
	);
	const overlapSnap = await getDocs(overlapQ);
	for (const d of overlapSnap.docs) {
		const ex = d.data();
		const exStart = ex.startAt.toDate();
		const exEnd = ex.endAt.toDate();
		const overlaps = exStart < endAtDate && startAtDate < exEnd;
		if (overlaps) {
			return alert('Slot bentrok untuk terapis tersebut. Silakan pilih jam lain.');
		}
	}

	const svcOpt = serviceSel.selectedOptions[0];
	const thOpt = therapistSel.selectedOptions[0];
	const serviceName = svcOpt?.dataset?.name || 'Service';
	const servicePrice = parseInt(svcOpt?.dataset?.price || '0', 10) || 0;
	const therapistName = thOpt?.dataset?.name || 'Therapist';

	await addDoc(collection(db, 'bookings'), {
		customerUid: CURRENT_USER.uid,
		customerName: cName.value.trim(),
		customerPhone: cPhone.value.trim(),
		serviceId: serviceSel.value,
		serviceName,
		servicePrice,
		therapistId: therapistSel.value,
		therapistName,
		startAt: Timestamp.fromDate(startAtDate),
		endAt: Timestamp.fromDate(endAtDate),
		durationMin,
		status: 'Pending',
		paymentStatus: 'unpaid',
		notes: notesInp.value.trim(),
		createdAt: serverTimestamp(),
	});

	notesInp.value = '';
	alert('Booking terkirim (Pending).');
});

function startCustomerBookingsWatcher(uid) {
	try { unsubMyBookings?.(); } catch {}
	unsubMyBookings = null;
	const qy = query(
		collection(db, 'bookings'),
		where('customerUid', '==', uid),
		orderBy('startAt', 'desc')
	);
	unsubMyBookings = onSnapshot(qy, (snap) => {
		myCount.textContent = `• ${snap.size} booking`;

		const docs = snap.docs;
		renderRecommendationsFromHistory(docs.map((d) => d.data()));

		myBookings.innerHTML = docs
			.map((d) => {
				const b = d.data();
				const start = b.startAt?.toDate ? b.startAt.toDate() : new Date();
				const end = b.endAt?.toDate ? b.endAt.toDate() : new Date();
				const date = toISODate(start);
				const time = `${pad2(start.getHours())}:${pad2(start.getMinutes())}–${pad2(end.getHours())}:${pad2(end.getMinutes())}`;
				return `
					<tr>
						<td>${date}</td>
						<td>${time}</td>
						<td>${escapeHtml(b.serviceName)} (Rp${b.servicePrice || 0})</td>
						<td>${escapeHtml(b.therapistName)}</td>
						<td><span class="badge" data-variant="${badgeVariant(b.status)}">${b.status}</span></td>
						<td>${escapeHtml(b.paymentStatus || 'unpaid')}</td>
					</tr>
				`;
			})
			.join('');
	});
}

function renderRecommendationsFromHistory(historyRows) {
	// Enhanced recommender (tanpa backend ML):
	// - Top layanan dari riwayat
	// - Terapis favorit dari riwayat
	// - Jam favorit (mode jam mulai)
	// - 1 tombol "Pakai semua saran" untuk auto-fill form
	if (!recommendations || !recHint) return;

	// No master data yet
	if (!SERVICES.length || !THERAPISTS.length) {
		recHint.textContent = '• master data belum ada';
		recommendations.innerHTML = '';
		return;
	}

	const byService = new Map();
	const byTherapist = new Map();
	const byHour = new Map();

	for (const b of historyRows) {
		const sKey = b.serviceId || '';
		if (sKey) byService.set(sKey, (byService.get(sKey) || 0) + 1);

		const tKey = b.therapistId || '';
		if (tKey) byTherapist.set(tKey, (byTherapist.get(tKey) || 0) + 1);

		try {
			const start = b.startAt?.toDate ? b.startAt.toDate() : null;
			if (start) {
				const hh = pad2(start.getHours());
				byHour.set(hh, (byHour.get(hh) || 0) + 1);
			}
		} catch {}
	}

	const hasHistory = byService.size > 0 || byTherapist.size > 0;
	if (hasHistory) {
		recHint.textContent = '• berdasarkan kebiasaan booking Anda';
	} else {
		recHint.textContent = '• rekomendasi default (belum ada riwayat)';
	}

	// pick top 3 services
	let servicePicks = [];
	if (byService.size) {
		servicePicks = [...byService.entries()]
			.sort((a, b) => b[1] - a[1])
			.slice(0, 3)
			.map(([id]) => id);
	}

	const svcById = new Map(SERVICES.map((s) => [s.id, s]));
	let recServices = servicePicks.map((id) => svcById.get(id)).filter(Boolean);
	if (recServices.length === 0) {
		// fallback: top 3 by price
		recServices = [...SERVICES]
			.sort((a, b) => (b.price || 0) - (a.price || 0))
			.slice(0, 3);
	}

	// therapist pick
	const thById = new Map(THERAPISTS.map((t) => [t.id, t]));
	let therapistPick = null;
	if (byTherapist.size) {
		const topT = [...byTherapist.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
		therapistPick = thById.get(topT) || null;
	}
	if (!therapistPick) therapistPick = THERAPISTS[0] || null;

	// hour pick
	let hourPick = null;
	if (byHour.size) {
		hourPick = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
	}
	if (!hourPick) hourPick = '11';
	const timePick = `${hourPick}:00`;

	// build cards
	const svcCards = recServices
		.map((s) => {
			return `
				<div class="col-4 card" style="padding:14px 14px">
					<div class="row" style="justify-content:space-between">
						<span class="badge" data-variant="blue">${escapeHtml(s.name)}</span>
						<span class="badge" data-variant="green">Rp${s.price || 0}</span>
					</div>
					<div class="hr"></div>
					<p class="small">Saran layanan untuk booking berikutnya.</p>
					<div class="row" style="justify-content:flex-end; margin-top: 10px">
						<button class="btn" data-variant="primary" type="button" data-rec-service="${s.id}">Pilih layanan</button>
					</div>
				</div>
			`;
		})
		.join('');

	const preferenceCard = `
		<div class="col-12 card" style="padding:14px 14px">
			<div class="row" style="justify-content:space-between">
				<span class="badge" data-variant="orange">Preferensi</span>
				<span class="small">Terapis & jam favorit</span>
			</div>
			<div class="hr"></div>
			<div class="grid">
				<div class="col-6">
					<p class="small">Terapis disarankan: <strong>${escapeHtml(therapistPick?.name || '-')}</strong></p>
				</div>
				<div class="col-6">
					<p class="small">Jam disarankan: <strong>${timePick}</strong></p>
				</div>
				<div class="col-12 row" style="justify-content:flex-end">
					<button class="btn" data-variant="primary" type="button" id="btnApplyAll">Pakai saran (isi form)</button>
				</div>
			</div>
		</div>
	`;

	recommendations.innerHTML = preferenceCard + svcCards;

	recommendations.querySelectorAll('button[data-rec-service]').forEach((btn) => {
		btn.addEventListener('click', () => {
			const id = btn.dataset.recService;
			serviceSel.value = id;
			serviceSel.dispatchEvent(new Event('change'));
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	});

	const btnApplyAll = document.getElementById('btnApplyAll');
	if (btnApplyAll) {
		btnApplyAll.addEventListener('click', () => {
			if (therapistPick?.id) therapistSel.value = therapistPick.id;
			timeInp.value = timePick;
			refreshHint();
			window.scrollTo({ top: 0, behavior: 'smooth' });
		});
	}
}

/* ===== Admin dashboard ===== */
function startAdminBookingsWatcher() {
	try { unsubAllBookings?.(); } catch {}
	unsubAllBookings = null;
	const qy = query(collection(db, 'bookings'), orderBy('startAt', 'desc'));
	unsubAllBookings = onSnapshot(qy, (snap) => {
		allCount.textContent = `• ${snap.size} booking`;

		const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
		renderStats(rows);
		renderAdminTable(rows);
	});
}

function renderStats(rows) {
	const today = toISODate(new Date());
	const monthKey = today.slice(0, 7);
	const isCanceled = (b) => b.status === 'Canceled';

	const todayRows = rows.filter((b) => !isCanceled(b) && toISODate(b.startAt.toDate()) === today);
	const monthRows = rows.filter((b) => !isCanceled(b) && toISODate(b.startAt.toDate()).startsWith(monthKey));

	const revenueToday = todayRows
		.filter((b) => ['Confirmed', 'Completed'].includes(b.status))
		.reduce((sum, b) => sum + (b.servicePrice || 0), 0);
	const revenueMonth = monthRows
		.filter((b) => ['Confirmed', 'Completed'].includes(b.status))
		.reduce((sum, b) => sum + (b.servicePrice || 0), 0);

	const pending = rows.filter((b) => b.status === 'Pending').length;
	const confirmed = rows.filter((b) => b.status === 'Confirmed').length;

	const cards = [
		{ label: 'Booking hari ini', value: todayRows.length, caption: 'non-canceled' },
		{ label: 'Pendapatan hari ini', value: `Rp${revenueToday}`, caption: 'Confirmed/Completed' },
		{ label: 'Booking bulan ini', value: monthRows.length, caption: monthKey },
		{ label: 'Pendapatan bulan ini', value: `Rp${revenueMonth}`, caption: 'Confirmed/Completed' },
		{ label: 'Pending', value: pending, caption: 'perlu konfirmasi' },
		{ label: 'Confirmed', value: confirmed, caption: 'siap jalan' },
	];

	statGrid.innerHTML = cards
		.map(
			(c) => `
				<div class="stat">
					<p class="lbl">${c.label}</p>
					<p class="val">${c.value}</p>
					<p class="cap">${c.caption}</p>
				</div>
			`
		)
		.join('');
}

function renderAdminTable(rows) {
	allBookings.innerHTML = rows
		.map((b) => {
			const start = b.startAt.toDate();
			const end = b.endAt.toDate();
			const date = toISODate(start);
			const time = `${pad2(start.getHours())}:${pad2(start.getMinutes())}–${pad2(end.getHours())}:${pad2(end.getMinutes())}`;
			return `
				<tr>
					<td>${escapeHtml(b.customerName)}</td>
					<td>${escapeHtml(b.customerPhone)}</td>
					<td>${date}</td>
					<td>${time}</td>
					<td>${escapeHtml(b.serviceName)}<div class="small">Rp${b.servicePrice || 0}</div></td>
					<td>${escapeHtml(b.therapistName)}</td>
					<td>
						<select data-action="status" data-id="${b.id}">
							${['Pending', 'Confirmed', 'Completed', 'Canceled']
								.map((s) => `<option ${s === b.status ? 'selected' : ''}>${s}</option>`)
								.join('')}
						</select>
					</td>
					<td>
						<button class="btn" data-action="delete" data-id="${b.id}" type="button">Hapus</button>
					</td>
				</tr>
			`;
		})
		.join('');

	allBookings.querySelectorAll('select[data-action="status"]').forEach((sel) => {
		sel.addEventListener('change', async () => {
			const id = sel.dataset.id;
			await updateDoc(doc(db, 'bookings', id), { status: sel.value });
		});
	});
	allBookings.querySelectorAll('button[data-action="delete"]').forEach((btn) => {
		btn.addEventListener('click', async () => {
			const id = btn.dataset.id;
			if (!confirm('Hapus booking ini?')) return;
			await deleteDoc(doc(db, 'bookings', id));
		});
	});
}

/* ===== Master data CRUD (admin/staff by rules) ===== */
btnAddService.addEventListener('click', async () => {
	if (!CURRENT_USER) return alert('Harus login.');
	await addDoc(collection(db, 'services'), {
		name: svcName.value.trim(),
		price: parseInt(svcPrice.value || '0', 10) || 0,
		createdAt: serverTimestamp(),
	});
	svcName.value = '';
	svcPrice.value = '';
});

btnAddTherapist.addEventListener('click', async () => {
	if (!CURRENT_USER) return alert('Harus login.');
	await addDoc(collection(db, 'therapists'), {
		name: thName.value.trim(),
		createdAt: serverTimestamp(),
	});
	thName.value = '';
});

btnAddProduct.addEventListener('click', async () => {
	if (!CURRENT_USER) return alert('Harus login.');
	await addDoc(collection(db, 'products'), {
		name: pName.value.trim(),
		sku: pSku.value.trim(),
		qty: parseInt(pQty.value || '0', 10) || 0,
		updatedAt: serverTimestamp(),
	});
	pName.value = '';
	pSku.value = '';
	pQty.value = '0';
});

function renderServicesTable() {
	svcTable.innerHTML = SERVICES.map((s) => `
		<tr>
			<td>${escapeHtml(s.name)}</td>
			<td>Rp${s.price || 0}</td>
			<td><button class="btn" type="button" data-svc-del="${s.id}">Hapus</button></td>
		</tr>
	`).join('');
	svcTable.querySelectorAll('button[data-svc-del]').forEach((b) => {
		b.addEventListener('click', async () => {
			if (!confirm('Hapus layanan?')) return;
			await deleteDoc(doc(db, 'services', b.dataset.svcDel));
		});
	});
}

function renderTherapistsTable() {
	thTable.innerHTML = THERAPISTS.map((t) => `
		<tr>
			<td>${escapeHtml(t.name)}</td>
			<td><button class="btn" type="button" data-th-del="${t.id}">Hapus</button></td>
		</tr>
	`).join('');
	thTable.querySelectorAll('button[data-th-del]').forEach((b) => {
		b.addEventListener('click', async () => {
			if (!confirm('Hapus terapis?')) return;
			await deleteDoc(doc(db, 'therapists', b.dataset.thDel));
		});
	});
}

function renderProductsTable(products) {
	pTable.innerHTML = products.map((p) => `
		<tr>
			<td>${escapeHtml(p.name)}</td>
			<td>${escapeHtml(p.sku || '-') }</td>
			<td><strong>${p.qty ?? 0}</strong></td>
			<td>
				<button class="btn" type="button" data-p-dec="${p.id}" data-current="${p.qty ?? 0}">-1</button>
				<button class="btn" type="button" data-p-inc="${p.id}" data-current="${p.qty ?? 0}">+1</button>
				<button class="btn" type="button" data-p-del="${p.id}">Hapus</button>
			</td>
		</tr>
	`).join('');

	pTable.querySelectorAll('button[data-p-inc]').forEach((b) => {
		b.addEventListener('click', async () => {
			const id = b.dataset.pInc;
			const cur = parseInt(b.dataset.current || '0', 10) || 0;
			await updateDoc(doc(db, 'products', id), { qty: cur + 1, updatedAt: serverTimestamp() });
			await addDoc(collection(db, 'stockMoves'), { productId: id, delta: 1, at: serverTimestamp() });
		});
	});
	pTable.querySelectorAll('button[data-p-dec]').forEach((b) => {
		b.addEventListener('click', async () => {
			const id = b.dataset.pDec;
			const cur = parseInt(b.dataset.current || '0', 10) || 0;
			if (cur - 1 < 0) return;
			await updateDoc(doc(db, 'products', id), { qty: cur - 1, updatedAt: serverTimestamp() });
			await addDoc(collection(db, 'stockMoves'), { productId: id, delta: -1, at: serverTimestamp() });
		});
	});
	pTable.querySelectorAll('button[data-p-del]').forEach((b) => {
		b.addEventListener('click', async () => {
			if (!confirm('Hapus produk?')) return;
			await deleteDoc(doc(db, 'products', b.dataset.pDel));
		});
	});
}

/* ===== Seed master data ===== */
btnSeed.addEventListener('click', async () => {
	if (!CURRENT_USER) return alert('Harus login.');
	// seed only if empty
	const svcSnap = await getDocs(query(collection(db, 'services'), limit(1)));
	if (svcSnap.empty) {
		await addDoc(collection(db, 'services'), { name: 'Full Body Massage', price: 200000, createdAt: serverTimestamp() });
		await addDoc(collection(db, 'services'), { name: 'Reflexology', price: 150000, createdAt: serverTimestamp() });
		await addDoc(collection(db, 'services'), { name: 'Hot Stone', price: 250000, createdAt: serverTimestamp() });
	}
	const thSnap = await getDocs(query(collection(db, 'therapists'), limit(1)));
	if (thSnap.empty) {
		await addDoc(collection(db, 'therapists'), { name: 'Ayu', createdAt: serverTimestamp() });
		await addDoc(collection(db, 'therapists'), { name: 'Bima', createdAt: serverTimestamp() });
		await addDoc(collection(db, 'therapists'), { name: 'Sari', createdAt: serverTimestamp() });
	}
	alert('Seed selesai (jika sebelumnya kosong).');
});

/* ===== Init ===== */
function initDefaults() {
	dateInp.value = toISODate(new Date());
	timeInp.value = nowHHMM();
	refreshHint();
}

onAuthStateChanged(auth, async (user) => {
	// stop any previous listeners first (bug fix)
	stopAllWatchers();
	CURRENT_USER = user;
	CURRENT_ROLE = null;

	if (!user) {
		setAuthUi({ user: null, role: null });
		return;
	}

	await ensureUserDoc(user.uid, user.email || '', 'customer');
	const role = await fetchRole(user.uid);
	CURRENT_ROLE = role;
	setAuthUi({ user, role });

	// watchers
	startMasterWatchers(role);
	startCustomerBookingsWatcher(user.uid);
	if (role === 'admin' || role === 'staff') startAdminBookingsWatcher();
});

initDefaults();
